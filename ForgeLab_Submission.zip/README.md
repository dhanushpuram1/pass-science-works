# ForgeLab — Unified Engineering Workbench

ForgeLab now has a loopback REST backend (C++17, cpp-httplib), an Eigen steady-state solver, worker telemetry, threaded UART/SPI simulation, contextual regression, and a Three.js shader viewer. Start with **Launch.exe** after building the C++ service; it starts the service and opens `http://127.0.0.1:8765`. `Launch.bat` remains a browser-only fallback.

## Included modules

- Geometry: STL surface and measured temperature points colored continuously by a custom WebGL shader; OrbitControls provides rotate/zoom/pan. Three.js and its STL loader are pinned to CDN version 0.128.0; use the existing 2D preview if offline.
- Thermal: linear two-node FEM assembly, Eigen LDLT solve, four mesh sizes, maximum/mean/weighted-L2 errors and residual.
- Performance: same 10/20/40/80 thermal batch run serially and in parallel, with one warm-up, repeated timings, result agreement, speedup, efficiency and utilization.
- Hardware: MCU, FPGA and JTAG mock lifecycles with capabilities, telemetry, UART/SPI/JTAG activity, injected timeout and retry recovery.
- Learning: OOP Neuron/Layer/Network contextual regressor with central finite-difference checks for every parameter.

## Build the C++ backend (Windows 11 x64)

Install Visual Studio Build Tools with the **Desktop development with C++** workload and CMake. The first configure step downloads pinned Eigen 3.4.0 and cpp-httplib v0.18.3 via CMake FetchContent, so it needs network access. From a Developer PowerShell:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
New-Item -ItemType Directory -Force dist | Out-Null
Copy-Item build/Release/ForgeLabBackend.exe dist/
```

`Launch.exe` is a .NET Framework launcher that starts `ForgeLabBackend.exe` when present, then opens the loopback UI. Its source is `Launch.cs`.

## Backend commands

Run the service from the project root. It serves the UI and REST endpoints on loopback port 8765.

```powershell
build/Release/ForgeLabBackend.exe
```

Routes: `GET /api/health`, `/api/thermal?elements=80&length=1&hot=100&cold=20&generation=0&conductivity=45&area=0.0001`, `/api/performance?workers=4&repetitions=5`, `/api/hardware?fault=FPGA` (fault supports Microcontroller, FPGA, or JTAG adapter), and `/api/train?steps=100`. The server binds only to `127.0.0.1`. Performance is machine-specific.

## Verification

```powershell
python tests/smoke_checks.py
```

Run `ctest --test-dir build --output-on-failure` for backend unit coverage, plus `python tests/smoke_checks.py`. `docs/DEMO_WALKTHROUGH.md` includes a 3–5 minute presentation sequence. `docs/AI_USAGE_LOG.md` records AI assistance.

## CSV / geometry formats

Temperature CSV accepts a header containing `temperature_C` and coordinate columns `x`, `y`, `z` (or `x_mm`, `y_mm`, `z_mm` / `x_m`, `y_m`, `z_m`). STL is binary or ASCII. The canvas viewer is a basic visualization preview, not a mesh repair or engineering certification tool.
