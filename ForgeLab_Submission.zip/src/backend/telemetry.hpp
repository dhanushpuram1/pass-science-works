#pragma once
#include <cstddef>
#include <vector>
#include "thermal.hpp"
namespace forge {
struct TelemetrySample { unsigned workers=0; double elapsedMs=0, speedup=0, efficiency=0, utilization=0, bottleneckRatio=0; };
struct ThermalBenchmarkRow { unsigned workers=0; double serialMs=0,parallelMs=0,speedup=0,efficiency=0,maxDifference=0,utilization=0; };
class Telemetry {
public:
    std::vector<TelemetrySample> profile(std::size_t work,unsigned maxWorkers=4) const;
    std::vector<ThermalBenchmarkRow> thermalBatch(const std::vector<ThermalInput>& cases,unsigned maxWorkers=4,unsigned repetitions=5) const;
};
}
