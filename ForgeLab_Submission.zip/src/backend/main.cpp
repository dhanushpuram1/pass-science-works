#include "thermal.hpp"
#include "telemetry.hpp"
#include "hardware.hpp"
#include "network.hpp"
#include <httplib.h>
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace {
using namespace forge;
double query(const httplib::Request&r,const char*k,double fallback){if(!r.has_param(k))return fallback;try{return std::stod(r.get_param_value(k));}catch(...){throw std::invalid_argument(std::string("Invalid query parameter: ")+k);}}
std::string json(const ThermalInput&p,const ThermalResult&r){std::ostringstream s;s<<"{\"elements\":"<<p.elements<<",\"mae\":"<<r.meanAbsoluteError<<",\"maxError\":"<<r.maximumAbsoluteError<<",\"l2Error\":"<<r.l2Error<<",\"residual\":"<<r.residualInfinity<<",\"x\":[";for(std::size_t i=0;i<r.x.size();++i){if(i)s<<',';s<<r.x[i];}s<<"],\"temperature\":[";for(std::size_t i=0;i<r.temperature.size();++i){if(i)s<<',';s<<r.temperature[i];}s<<"],\"analytical\":[";for(std::size_t i=0;i<r.analytical.size();++i){if(i)s<<',';s<<r.analytical[i];}s<<"]}";return s.str();}
void jsonError(httplib::Response&res,const std::exception&e){res.status=400;res.set_content(std::string("{\"error\":\"")+e.what()+"\"}","application/json");}
void serveFile(const httplib::Request&,httplib::Response&res,const std::string&path,const char*type){std::ifstream f(path,std::ios::binary);if(!f){res.status=404;res.set_content("Not found","text/plain");return;}std::ostringstream b;b<<f.rdbuf();res.set_content(b.str(),type);}
}
int main(){using namespace forge;httplib::Server server;server.set_payload_max_length(8*1024*1024);server.set_read_timeout(5,0);server.set_write_timeout(5,0);
    server.Get("/",[](const auto&r,auto&res){serveFile(r,res,"index.html","text/html; charset=utf-8");});
    server.Get("/src/frontend/app.js",[](const auto&r,auto&res){serveFile(r,res,"src/frontend/app.js","text/javascript; charset=utf-8");});
    server.Get("/src/frontend/styles.css",[](const auto&r,auto&res){serveFile(r,res,"src/frontend/styles.css","text/css; charset=utf-8");});
    server.Get("/src/frontend/three-viewer.js",[](const auto&r,auto&res){serveFile(r,res,"src/frontend/three-viewer.js","text/javascript; charset=utf-8");});
    server.Get("/api/health",[](const auto&,auto&res){res.set_content("{\"status\":\"ok\",\"version\":\"1.0.0\"}","application/json");});
    server.Get("/api/thermal",[](const auto&r,auto&res){try{ThermalInput p;p.elements=static_cast<int>(query(r,"elements",80));p.length=query(r,"length",1);p.hot=query(r,"hot",100);p.cold=query(r,"cold",20);p.generation=query(r,"generation",0);p.conductivity=query(r,"conductivity",45);p.area=query(r,"area",1e-4);res.set_content(json(p,solveThermal(p)),"application/json");}catch(const std::exception&e){jsonError(res,e);}});
    server.Get("/api/performance",[](const auto&r,auto&res){try{ThermalInput base;base.length=query(r,"length",1);base.hot=query(r,"hot",100);base.cold=query(r,"cold",20);base.generation=query(r,"generation",0);base.conductivity=query(r,"conductivity",45);base.area=query(r,"area",1e-4);std::vector<ThermalInput> batch;for(int n:{10,20,40,80}){auto p=base;p.elements=n;batch.push_back(p);}Telemetry t;auto samples=t.thermalBatch(batch,static_cast<unsigned>(query(r,"workers",4)),static_cast<unsigned>(query(r,"repetitions",5)));std::ostringstream s;s<<"{\"workload\":\"same thermal mesh batch, serial versus parallel\",\"warmups\":1,\"repetitions\":"<<query(r,"repetitions",5)<<",\"samples\":[";for(std::size_t i=0;i<samples.size();++i){if(i)s<<',';const auto&v=samples[i];s<<"{\"workers\":"<<v.workers<<",\"serialMs\":"<<v.serialMs<<",\"parallelMs\":"<<v.parallelMs<<",\"speedup\":"<<v.speedup<<",\"efficiency\":"<<v.efficiency<<",\"maxDifference\":"<<v.maxDifference<<",\"utilization\":"<<v.utilization<<'}';}s<<"]}";res.set_content(s.str(),"application/json");}catch(const std::exception&e){jsonError(res,e);}});
    server.Get("/api/hardware",[](const auto&r,auto&res){try{HardwareSimulator sim;auto events=sim.run(r.has_param("fault")?r.get_param_value("fault"):"Microcontroller");std::ostringstream s;s<<"{\"events\":[";for(std::size_t i=0;i<events.size();++i){if(i)s<<',';const auto&e=events[i];s<<"{\"bus\":\""<<e.bus<<"\",\"message\":\""<<e.message<<"\",\"atMs\":"<<e.atMs<<",\"interrupt\":"<<(e.interrupt?"true":"false")<<'}';}s<<"]}";res.set_content(s.str(),"application/json");}catch(const std::exception&e){jsonError(res,e);}});
    server.Get("/api/train",[](const auto&r,auto&res){try{const double steps=query(r,"steps",100);if(steps<1||steps>5000)throw std::invalid_argument("steps must be 1..5000");Network n;auto curve=n.train(static_cast<unsigned>(steps));const TrainingPoint sample{45,1,100,20,0,60};auto checks=n.checkAllGradients(sample);double maxRelative=0;for(const auto&c:checks)maxRelative=std::max(maxRelative,c.relativeError);std::ostringstream s;s<<"{\"loss\":[";for(std::size_t i=0;i<curve.size();++i){if(i)s<<',';s<<curve[i];}s<<"],\"samplePrediction\":"<<n.predict(sample)<<",\"gradientCheck\":{\"parameterCount\":"<<checks.size()<<",\"maxRelativeError\":"<<maxRelative<<"}}";res.set_content(s.str(),"application/json");}catch(const std::exception&e){jsonError(res,e);}});
    server.set_error_handler([](const auto&,auto&res){res.set_content("{\"error\":\"route not found\"}","application/json");});
    constexpr const char* host="127.0.0.1";constexpr int port=8765;std::cout<<"ForgeLab API: http://"<<host<<':'<<port<<"\n";if(!server.listen(host,port)){std::cerr<<"Could not bind loopback port "<<port<<'\n';return 2;}return 0;
}
