#include "telemetry.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <limits>
#include <cstdlib>
#include <thread>
#include <vector>
#include <stdexcept>
namespace forge {
std::vector<TelemetrySample> Telemetry::profile(std::size_t work,unsigned maxWorkers) const {
    maxWorkers=std::clamp(maxWorkers,1u,4u);std::vector<TelemetrySample> out;double baseline=0;
    for(unsigned count=1;count<=maxWorkers;++count){std::atomic<unsigned> ready{0};std::atomic<bool> start{false};std::vector<double> busy(count,0);std::vector<std::thread> pool;pool.reserve(count);const auto wallStart=std::chrono::steady_clock::now();
        for(unsigned w=0;w<count;++w)pool.emplace_back([&,w]{ready.fetch_add(1);while(!start.load(std::memory_order_acquire))std::this_thread::yield();const auto t0=std::chrono::steady_clock::now();const std::size_t first=work*w/count,last=work*(w+1)/count;double sum=0;for(std::size_t i=first;i<last;++i)sum+=std::sin(i*.001)*std::cos(i*.0001);busy[w]=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();if(sum==std::numeric_limits<double>::infinity())std::abort();});
        while(ready.load()<count)std::this_thread::yield();start.store(true,std::memory_order_release);for(auto& t:pool)t.join();const double wall=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-wallStart).count();double active=0;for(double v:busy)active+=v;const double speed=count==1?1.0:baseline/wall;if(count==1)baseline=wall;out.push_back({count,wall,speed,speed/count,std::clamp(active/(wall*count),0.0,1.0),wall>0?std::max(0.0,(wall-*std::max_element(busy.begin(),busy.end()))/wall):0});}
    return out;
}
std::vector<ThermalBenchmarkRow> Telemetry::thermalBatch(const std::vector<ThermalInput>& cases,unsigned maxWorkers,unsigned repetitions) const {
    if(cases.empty())throw std::invalid_argument("Thermal benchmark requires at least one case");
    if(repetitions<1||repetitions>50)throw std::invalid_argument("repetitions must be 1..50");
    maxWorkers=std::clamp(maxWorkers,1u,4u);std::vector<ThermalBenchmarkRow> rows;
    auto serial=[&]{std::vector<ThermalResult> result;result.reserve(cases.size());for(const auto&p:cases)result.push_back(solveThermal(p));return result;};
    for(unsigned workers=1;workers<=maxWorkers;++workers){std::vector<double> busy(workers);auto parallel=[&]{std::vector<ThermalResult> result(cases.size());std::vector<std::thread> pool;for(unsigned w=0;w<workers;++w)pool.emplace_back([&,w]{const auto start=std::chrono::steady_clock::now();for(std::size_t i=cases.size()*w/workers;i<cases.size()*(w+1)/workers;++i)result[i]=solveThermal(cases[i]);busy[w]=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();});for(auto&t:pool)t.join();return result;};
        (void)serial();(void)parallel();double serialMs=0,parallelMs=0,maxDiff=0;for(unsigned rep=0;rep<repetitions;++rep){auto start=std::chrono::steady_clock::now();auto a=serial();serialMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();start=std::chrono::steady_clock::now();auto b=parallel();parallelMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();for(std::size_t i=0;i<a.size();++i)for(std::size_t j=0;j<a[i].temperature.size();++j)maxDiff=std::max(maxDiff,std::abs(a[i].temperature[j]-b[i].temperature[j]));}
        serialMs/=repetitions;parallelMs/=repetitions;const double speed=parallelMs>0?serialMs/parallelMs:0;double active=0;for(double t:busy)active+=t;rows.push_back({workers,serialMs,parallelMs,speed,speed/workers,maxDiff,std::clamp(active/(parallelMs*workers),0.0,1.0)});
    }return rows;
}
}
