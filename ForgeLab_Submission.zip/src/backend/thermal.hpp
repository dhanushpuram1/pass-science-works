#pragma once
#include <Eigen/Dense>
#include <vector>
#include <stdexcept>
#include <cmath>

namespace forge {
struct ThermalInput { int elements=80; double length=1.0, hot=100.0, cold=20.0, generation=0.0, conductivity=45.0, area=1e-4; };
struct ThermalResult { std::vector<double> x, temperature, analytical; double meanAbsoluteError=0.0, maximumAbsoluteError=0.0, l2Error=0.0, residualInfinity=0.0; };
inline ThermalResult solveThermal(const ThermalInput& p) {
    if(p.elements<2 || p.elements>10000 || p.length<=0 || p.conductivity<=0 || p.area<=0 || !std::isfinite(p.length*p.conductivity*p.area)) throw std::invalid_argument("Elements must be 2..10000; geometry and material properties must be positive finite values");
    const int m=p.elements-1; const double dx=p.length/p.elements; const double stiffness=p.conductivity*p.area/dx;
    Eigen::MatrixXd A=Eigen::MatrixXd::Zero(m,m); Eigen::VectorXd b=Eigen::VectorXd::Zero(m);
    // Assemble each linear two-node element: ke=(kA/h)[[1,-1],[-1,1]],
    // fe=(qA h/2)[1,1]. Eliminate the fixed endpoint degrees of freedom.
    for(int e=0;e<p.elements;++e){const int nodes[2]={e,e+1};for(int a=0;a<2;++a){const int i=nodes[a];const double load=p.generation*p.area*dx*.5;if(i>0&&i<p.elements)b(i-1)+=load;for(int c=0;c<2;++c){const int j=nodes[c];const double kij=stiffness*(a==c?1.0:-1.0);if(i>0&&i<p.elements){if(j>0&&j<p.elements)A(i-1,j-1)+=kij;else b(i-1)-=kij*(j==0?p.hot:p.cold);}}}}
    const Eigen::VectorXd interior=A.ldlt().solve(b);
    if(!interior.allFinite()) throw std::runtime_error("Eigen solver returned non-finite temperatures");
    ThermalResult out;out.x.reserve(p.elements+1);out.temperature.reserve(p.elements+1);out.analytical.reserve(p.elements+1);
    out.x.push_back(0);out.temperature.push_back(p.hot);
    for(int i=1;i<p.elements;++i){out.x.push_back(i*dx);out.temperature.push_back(interior(i-1));}
    out.x.push_back(p.length);out.temperature.push_back(p.cold);
    double squared=0,abs=0;for(int i=0;i<=p.elements;++i){const double x=out.x[static_cast<std::size_t>(i)];const double exact=p.hot+(p.cold-p.hot)*x/p.length+p.generation*x*(p.length-x)/(2*p.conductivity);out.analytical.push_back(exact);const double error=std::abs(out.temperature[static_cast<std::size_t>(i)]-exact);abs+=error;squared+=error*error;out.maximumAbsoluteError=std::max(out.maximumAbsoluteError,error);}
    out.meanAbsoluteError=abs/out.x.size();out.l2Error=std::sqrt(squared*dx);out.residualInfinity=(A*interior-b).lpNorm<Eigen::Infinity>();return out;
}
}
