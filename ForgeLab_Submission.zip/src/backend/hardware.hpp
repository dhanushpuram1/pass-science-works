#pragma once
#include <string>
#include <vector>
namespace forge {
struct HardwareEvent { std::string bus, message; double atMs=0; bool interrupt=false; };
class HardwareSimulator {
public: std::vector<HardwareEvent> run(const std::string& faultDevice="Microcontroller") const;
};
}
