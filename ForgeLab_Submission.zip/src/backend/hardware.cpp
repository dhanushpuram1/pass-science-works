#include "hardware.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <mutex>
#include <stdexcept>
#include <thread>
namespace forge {
namespace {
using Clock=std::chrono::steady_clock;
enum class State{Disconnected,Discovered,Connected,Streaming,Error,Recovering};
struct MockDevice{std::string name,features;State state=State::Disconnected;};
}
std::vector<HardwareEvent> HardwareSimulator::run(const std::string& faultDevice) const {
    const auto origin=Clock::now();std::mutex mutex;std::vector<HardwareEvent> events;std::atomic<bool> uartIrq{false},spiIrq{false};
    auto log=[&](const std::string&device,const std::string&msg,bool irq=false){std::lock_guard<std::mutex> guard(mutex);events.push_back({device,msg,std::chrono::duration<double,std::milli>(Clock::now()-origin).count(),irq});};
    auto lifecycle=[&](MockDevice d){log(d.name,"Disconnected -> Discovered");d.state=State::Discovered;log(d.name,"Capabilities: "+d.features);d.state=State::Connected;log(d.name,"Discovered -> Connected");d.state=State::Streaming;log(d.name,"Connected -> Streaming; telemetry packet received");std::this_thread::sleep_for(std::chrono::milliseconds(3));if(d.name==faultDevice){d.state=State::Error;log(d.name,"Injected timeout -> Error");d.state=State::Recovering;log(d.name,"Error -> Recovering; reconnect attempt");d.state=State::Connected;log(d.name,"Recovering -> Connected; retry successful");}d.state=State::Disconnected;log(d.name,"Connected -> Disconnected");};
    MockDevice mcu{"Microcontroller","UART 115200 baud; GPIO; 3.3 V telemetry"},fpga{"FPGA","SPI mode 0; status register; 3.3 V logic"},jtag{"JTAG adapter","TCK/TMS/TDI/TDO; target IDCODE"};
    std::thread uart([&]{lifecycle(mcu);log("UART","TX start: 0xA5 @ 115200 baud");for(int bit=0;bit<10;++bit)std::this_thread::sleep_for(std::chrono::microseconds(87));uartIrq=true;log("UART","RX complete: 0xA5; receive interrupt asserted",true);});
    std::thread spi([&]{lifecycle(fpga);log("SPI","Chip select asserted; mode 0; 1 MHz");std::uint8_t tx=0x3C,rx=0;for(int bit=7;bit>=0;--bit){rx=static_cast<std::uint8_t>((rx<<1)|((tx>>bit)&1));std::this_thread::sleep_for(std::chrono::microseconds(1));}spiIrq=true;log("SPI","8 clocks; RX byte matched TX 0x"+std::string(rx==tx?"3C":"00")+"; transfer interrupt asserted",true);});
    std::thread jtagThread([&]{lifecycle(jtag);std::uint32_t idcode=0x0362D093;unsigned shifted=0;for(int bit=0;bit<32;++bit){shifted=(shifted<<1)|((idcode>>(31-bit))&1);std::this_thread::sleep_for(std::chrono::microseconds(2));}log("JTAG","32 TCK cycles; IDCODE shifted: 0x"+(shifted==idcode?std::string("0362D093"):std::string("ERROR")),true);});
    uart.join();spi.join();jtagThread.join();if(!uartIrq||!spiIrq)throw std::runtime_error("Mock bus completion interrupt was not raised");std::sort(events.begin(),events.end(),[](const auto&a,const auto&b){return a.atMs<b.atMs;});return events;
}
}
