#pragma once
#include <vector>
#include <cstddef>
namespace forge {
class Neuron { double bias_=0; std::vector<double> weights_; public: explicit Neuron(unsigned inputs); double activate(const std::vector<double>& x) const; double& weight(std::size_t i){return weights_.at(i);} double& bias(){return bias_;} };
class Layer { std::vector<Neuron> neurons_; public: Layer(unsigned inputs,unsigned count); std::vector<double> forward(const std::vector<double>& x) const; std::vector<Neuron>& neurons(){return neurons_;} const std::vector<Neuron>& neurons()const{return neurons_;} };
struct TrainingPoint { double conductivity, length, hot, cold, generation, equilibrium; };
struct GradientCheck { double analytical=0,finiteDifference=0,relativeError=0; };
class Network { Layer hidden_; Layer output_; public: Network(); double predict(const TrainingPoint& x) const; std::vector<double> train(unsigned steps=100); GradientCheck checkOutputBiasGradient(const TrainingPoint& sample); std::vector<GradientCheck> checkAllGradients(const TrainingPoint& sample); };
}
