using System;
using System.Diagnostics;
using System.IO;

internal static class ForgeLabLauncher
{
    [STAThread]
    private static int Main()
    {
        string page = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "index.html");
        if (!File.Exists(page))
        {
            Console.Error.WriteLine("ForgeLab UI not found: " + page);
            return 1;
        }
        string backend = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ForgeLabBackend.exe");
        string target = page;
        if (File.Exists(backend))
        {
            try
            {
                Process.Start(new ProcessStartInfo { FileName = backend, WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden });
                System.Threading.Thread.Sleep(700);
                target = "http://127.0.0.1:8765/";
            }
            catch { target = page; }
        }
        Process.Start(new ProcessStartInfo { FileName = target, UseShellExecute = true });
        return 0;
    }
}
