@echo off
start "ForgeLab" "%~dp0index.html"
