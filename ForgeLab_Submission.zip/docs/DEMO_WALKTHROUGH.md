# 4-minute demonstration walkthrough

Use these timestamps as a recording guide. Capture the actual running interface; no video is fabricated or implied by this document.

- **00:00–00:25 — Overview:** introduce ForgeLab and the five modules. Point out the sample rod and temperature profile.
- **00:25–01:00 — Geometry:** open Geometry. Rotate with drag, zoom with the wheel, pan with Shift+drag. Import `data/sample_rod.stl`; load `data/temperature_points.csv` and show colored temperature points.
- **01:00–01:55 — Thermal analysis:** show material and boundary inputs. Run the analysis; compare 10, 20, 40, and 80 intervals and the analytical profile. Export `thermal_profile.csv`.
- **01:55–02:35 — Performance:** run the browser demonstration, explain speedup and efficiency. Show the C++ backend command and its thread implementation; distinguish native measurements from the browser visualization.
- **02:35–03:10 — Hardware:** show USB CDC, SPI/GPIO, and JTAG links. Run the mock handshake and state that no physical hardware is connected. Explain common ground and voltage compatibility.
- **03:10–03:50 — Backpropagation:** train for 100 steps, show loss curve and XOR outputs. Explain the sigmoid derivative and gradient update in one sentence.
- **03:50–04:00 — Close:** mention source, CMake build, tests, results, and remaining native Windows packaging step.

## Screenshot capture checklist

1. Overview dashboard.
2. Geometry with sample STL and temperature points mapped.
3. Thermal results table and graph.
4. Performance chart after a run.
5. Hardware mock console showing handshake complete.
6. Backpropagation loss curve and output table.
