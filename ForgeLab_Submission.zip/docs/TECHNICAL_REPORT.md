# ForgeLab Unified Engineering Workbench
## Technical report | 1 November 2026

### 1. Purpose and implementation status
ForgeLab combines geometry inspection, one-dimensional thermal finite-element analysis, multicore measurement, embedded-device simulation, and a contextual neural network in one browser interface. The C++17 backend serves a REST API on loopback address `127.0.0.1:8765`. Source and tests have been updated to match the detailed assessment checklist. JavaScript/Python checks pass; the C++ backend has not been compiled in this environment because CMake and a C++ compiler are unavailable. No runtime/CTest results are claimed.

### 2. Architecture
`main.cpp` owns cpp-httplib routes and input validation. `thermal.hpp` assembles and solves the FEM system with Eigen. `telemetry.*` runs equivalent serial and parallel thermal batches. `hardware.*` models three device lifecycles and UART/SPI/JTAG activity. `network.*` provides `Neuron`, `Layer`, and `Network` classes plus a finite-difference gradient checker. The browser uses Three.js, OrbitControls, and a custom GLSL heat shader; a Canvas preview remains available. Eigen 3.4.0 and cpp-httplib v0.18.3 are pinned through CMake FetchContent. Three.js 0.128.0 is pinned through CDN URLs.

### 3. Thermal finite-element method
For a uniform rod with length L, area A, conductivity k, generation q, and fixed endpoint temperatures, the equation is `d/dx(kA dT/dx)+qA=0`. A linear two-node element of length h contributes stiffness `ke=(kA/h)[[1,-1],[-1,1]]` and consistent source load `fe=(qAh/2)[1,1]`. Local matrices and vectors are assembled globally; the fixed endpoint degrees of freedom are eliminated. Eigen LDLT solves the symmetric positive-definite interior system.

The analytical reference is `T(x)=Th+(Tc-Th)x/L+q x(L-x)/(2k)`. Results include maximum absolute nodal error, mean absolute error, dx-weighted L2 nodal error, and algebraic residual infinity norm. Four mesh sizes (10, 20, 40, 80) are supported. This is a 1D steady FEM model, not a general 3D solver.

### 4. Serial/parallel performance methodology
The benchmark constructs one identical batch of 1D thermal cases at 10, 20, 40, and 80 elements. For each worker count (1–4), it discards a warm-up and averages configurable repeated runs measured with `steady_clock`. The response reports serial and parallel wall time, speedup `Tserial/Tparallel`, efficiency `speedup/p`, worker active-time utilization, and maximum absolute difference between serial and parallel temperature arrays. The frontend charts speedup and shows agreement/utilization. Measurements vary with CPU, compiler, thread creation overhead, and system load; telemetry is sampled at the end of each batch, not OS scheduler sampling.

### 5. Embedded mock devices
The MCU, FPGA, and JTAG adapter are separate concurrent mock devices. Each emits discovery, supported capabilities, connection, telemetry/streaming, and disconnect events. The API can inject a timeout for any named device; it transitions to Error, attempts recovery, and records successful reconnect. The UART mock sends a framed byte at nominal 115200 baud and raises an RX interrupt flag. The SPI mock shifts eight bits in mode 0 at nominal 1 MHz and raises a completion flag. The JTAG mock shifts a 32-bit IDCODE. All device behavior is simulated; no physical board is accessed.

### 6. Contextual backpropagation
The five inputs are normalized conductivity, rod length, hot/cold boundary temperatures, and heat generation. The target is the spatial mean equilibrium temperature derived from the analytical solution: `(Th+Tc)/2 + qL²/(12k)`. The OOP model contains Neuron, Layer, and Network classes and uses sigmoid activation. Backpropagation uses `sigma'(z)=sigma(z)(1-sigma(z))` and gradient descent. A central finite-difference check perturbs all 57 network parameters and reports the maximum relative difference from analytical gradients. The dataset is a small synthetic parameter grid; it does not support claims about prediction outside that range.

### 7. REST interface and frontend
- `GET /api/health`: service status/version.
- `GET /api/thermal`: FEM nodes, analytical profile, MAE, max error, weighted L2 error, and residual.
- `GET /api/performance`: same-batch serial/parallel results, repetitions, speedup, efficiency, utilization, and maximum result difference.
- `GET /api/hardware?fault=FPGA`: timestamped lifecycle and bus events; fault option supports Microcontroller, FPGA, or JTAG adapter.
- `GET /api/train?steps=100`: loss curve, sample prediction, and gradient-check summary.

The geometry module imports ASCII/binary STL and temperature CSV points, supports camera controls, and exports calculated CSV results. Full shader rendering needs network access for the pinned Three.js CDN; the Canvas preview is the fallback.

### 8. Verification and remaining work
The C++ unit test source checks FEM boundary values/residual/source/mesh refinement; serial-parallel thermal agreement; timeout recovery for all three devices; and gradient finite-difference agreement. Python smoke checks cover fixture formats and stored reference data. To complete verification, build with CMake and a C++17 compiler, run CTest, exercise each API route, record actual machine timings, inspect loss convergence and gradient tolerances, and capture the required demonstration video or timestamped screenshots. The hardware mock is not physical integration. AI assistance was used to draft code and documentation; review and disclose it per the assignment.
