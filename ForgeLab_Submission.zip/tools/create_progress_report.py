"""Create a detailed, compact project report PDF for the ForgeLab submission."""
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "ForgeLab_Progress_Report.pdf"
pdfmetrics.registerFont(TTFont("Arial", r"C:\Windows\Fonts\arial.ttf"))
pdfmetrics.registerFont(TTFont("Arial-Bold", r"C:\Windows\Fonts\arialbd.ttf"))
navy=colors.HexColor("#142232"); blue=colors.HexColor("#3478D8"); muted=colors.HexColor("#647487"); pale=colors.HexColor("#EEF4FC")
ss=getSampleStyleSheet()
ss.add(ParagraphStyle(name="TitleF",parent=ss["Title"],fontName="Arial-Bold",fontSize=22,leading=26,textColor=navy,alignment=TA_LEFT,spaceAfter=4))
ss.add(ParagraphStyle(name="SubF",parent=ss["Normal"],fontName="Arial",fontSize=9,leading=13,textColor=muted,spaceAfter=7))
ss.add(ParagraphStyle(name="H1F",parent=ss["Heading1"],fontName="Arial-Bold",fontSize=15,leading=19,textColor=navy,spaceBefore=1,spaceAfter=8))
ss.add(ParagraphStyle(name="H2F",parent=ss["Heading2"],fontName="Arial-Bold",fontSize=10.5,leading=13,textColor=navy,spaceBefore=7,spaceAfter=4))
ss.add(ParagraphStyle(name="BodyF",parent=ss["BodyText"],fontName="Arial",fontSize=8.6,leading=12,textColor=colors.HexColor("#304153"),spaceAfter=4))
ss.add(ParagraphStyle(name="SmallF",parent=ss["BodyText"],fontName="Arial",fontSize=7.5,leading=9.5,textColor=muted))
ss.add(ParagraphStyle(name="CellF",parent=ss["BodyText"],fontName="Arial",fontSize=7.6,leading=10,textColor=colors.HexColor("#304153")))
ss.add(ParagraphStyle(name="CellHeadF",parent=ss["BodyText"],fontName="Arial-Bold",fontSize=7.8,leading=10,textColor=navy))
ss.add(ParagraphStyle(name="CalloutF",parent=ss["BodyText"],fontName="Arial",fontSize=8.1,leading=11,textColor=navy))
def P(s,style="BodyF"): return Paragraph(s,ss[style])
def bullet(s): return P("&#8226; " + s,"BodyF")
def table(rows,widths,header=True):
    t=Table(rows,colWidths=widths,repeatRows=1 if header else 0,hAlign="LEFT")
    rules=[("GRID",(0,0),(-1,-1),.35,colors.HexColor("#DDE4EA")),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),("ROWBACKGROUNDS",(0,1 if header else 0),(-1,-1),[colors.white,colors.HexColor("#FAFBFD")])]
    if header: rules.append(("BACKGROUND",(0,0),(-1,0),colors.HexColor("#EAF0F6")))
    t.setStyle(TableStyle(rules));return t
def banner(label,text):
    t=Table([[P(label,"CellHeadF"),P(text,"CellF")]],colWidths=[33*mm,143*mm]);t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),pale),("BOX",(0,0),(-1,-1),.5,colors.HexColor("#D6E3F4")),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),8),("RIGHTPADDING",(0,0),(-1,-1),8),("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7)]));return t
doc=SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=17*mm,leftMargin=17*mm,topMargin=14*mm,bottomMargin=14*mm,title="ForgeLab Detailed Project Progress Report",author="ForgeLab Project")
story=[]
# PAGE 1: project purpose, architecture, task coverage.
story += [P("FORGELAB","TitleF"),P("Unified Engineering Workbench | Detailed project progress report | 1 November 2026","SubF"),banner("IMPLEMENTATION STATUS","Core source implementation is in place across the C++ backend and browser frontend. Frontend syntax and data smoke checks pass. Native C++ compilation, REST runtime checks, and the final demo recording are still pending."),P("1. Project overview","H1F"),P("ForgeLab is a single engineering workbench intended to bring geometry inspection, one-dimensional thermal analysis, multicore profiling, embedded-device simulation, and a small learning model into one interface. The application is split into a browser client and a C++17 service. The backend communicates over HTTP on the loopback interface (127.0.0.1), so its API is local to the user’s computer and is not exposed as a network service."),P("Architecture and key decisions","H2F"),bullet("Backend modules separate responsibilities: <b>main.cpp</b> defines HTTP routes; <b>thermal.hpp</b> assembles and solves the thermal system; <b>telemetry.*</b> runs timed worker profiles; <b>hardware.*</b> models serial buses; <b>network.*</b> implements the contextual neural network."),bullet("<b>cpp-httplib</b> provides a small header-only HTTP server. <b>Eigen</b> provides dense matrix types and LDLT factorization. CMake FetchContent pins Eigen 3.4.0 and cpp-httplib v0.18.3; first-time configuration therefore needs network access."),bullet("The frontend is HTML, CSS, and JavaScript. Three.js with OrbitControls and a custom GLSL shader is the preferred geometry view. A Canvas preview remains as a fallback. The Three.js scripts are pinned to 0.128.0 on a CDN, so full WebGL viewing needs internet access."),bullet("<b>Launch.exe</b> is a .NET Framework launcher. It starts ForgeLabBackend.exe when that file is present beside it, then opens the local web interface. The C++ backend executable itself has not been built in this environment."),P("Requirements coverage","H2F")]
coverage=[[P("Assignment area","CellHeadF"),P("Implementation in this project","CellHeadF"),P("Current state","CellHeadF")],
[P("A. Application","CellF"),P("Four engineering sections, shared navigation, form inputs, charts, import controls, status messages, and REST service structure.","CellF"),P("Source implemented","CellF")],
[P("B. Geometry","CellF"),P("STL surface rendering with continuous shader temperature coloring; temperature CSV points; rotate, zoom, and pan controls.","CellF"),P("Source implemented","CellF")],
[P("C. Thermal","CellF"),P("Linear two-node FEM stiffness/load assembly, Eigen LDLT, four mesh sizes, analytical comparison, max/mean/L2 errors and residual.","CellF"),P("Source implemented","CellF")],
[P("D. Performance","CellF"),P("Same thermal batch serial/parallel, warm-up, repeated timing, speedup, efficiency, utilization, and result agreement.","CellF"),P("Source implemented","CellF")],
[P("E. Hardware","CellF"),P("Independent UART/SPI threads with serial bit timing, latency, receive data, and interrupt flags.","CellF"),P("Software mock","CellF")],
[P("F. Learning","CellF"),P("OOP Neuron/Layer/Network sigmoid model predicts thermal equilibrium from rod/material inputs.","CellF"),P("Source implemented","CellF")]]
story += [table(coverage,[28*mm,119*mm,29*mm]),PageBreak()]
# PAGE 2: the engineering methods in practical detail.
story += [P("2. Engineering methods","H1F"),P("Thermal finite-element solve","H2F"),P("The solver models steady 1D conduction through a uniform rod with area A, conductivity k, volumetric generation q, and fixed endpoint temperatures: d/dx(kA dT/dx)+qA=0. Each linear two-node element of length h contributes ke=(kA/h)[[1,-1],[-1,1]] and a consistent load fe=(qAh/2)[1,1]. The element contributions are assembled into a global system and fixed endpoint degrees of freedom are eliminated."),P("Eigen LDLT solves the reduced symmetric positive-definite system. The analytical reference is T(x)=Th+(Tc-Th)x/L+q x(L-x)/(2k). The API returns nodal temperature, maximum/mean/weighted-L2 nodal error, and residual norm for 10, 20, 40, and 80 elements. This is 1D steady FEM, not a general 3D finite-element package."),P("Serial/parallel comparison","H2F"),P("The benchmark uses the same batch of thermal cases at 10, 20, 40, and 80 elements. For worker counts 1–4 it discards one warm-up and averages repeated runs measured with steady_clock. It reports serial time, parallel time, speedup, efficiency, active-time utilization, and maximum temperature difference between serial and parallel outputs. Timings depend on processor, compiler, thread startup, and system load; telemetry is sampled per batch, not read from the OS scheduler."),P("Embedded device lifecycle simulation","H2F"),P("Three concurrent mock devices represent a microcontroller, FPGA, and JTAG adapter. Each reports discovery, capabilities, connection, streaming telemetry, and disconnection. A caller can inject a timeout into any one device; it enters Error, attempts recovery, and records successful retry. The MCU mock shifts a framed UART byte at nominal 115200 baud and raises a receive interrupt. The FPGA mock performs an 8-bit SPI mode-0 transfer at nominal 1 MHz and raises a completion interrupt. The JTAG mock shifts a 32-bit IDCODE. No physical device is accessed."),PageBreak()]
# PAGE 3: learning, API contract, verification and handoff.
story += [P("3. Learning model, interface, and handoff","H1F"),P("Contextual machine learning","H2F"),P("The C++ learning code separates a <b>Neuron</b> (weights, bias, activation), a <b>Layer</b> (a group of neurons and forward propagation), and a <b>Network</b> (hidden/output layers, prediction, and training). The network has five normalized inputs: conductivity, rod length, hot-end temperature, cold-end temperature, and uniform heat generation. It predicts the spatial mean equilibrium temperature."),P("Training targets are generated from the analytical rod solution over a small grid of conductivities, lengths, heat-generation values, and boundary temperatures. With uniform generation, the mean target is (Th+Tc)/2 + qL²/(12k). Sigmoid derivatives propagate gradients backward; all 57 weights and biases are checked against central finite differences. The <b>/api/train</b> endpoint returns loss, a sample prediction, and maximum gradient-check error. This is a small educational regression model; it is not validated for extrapolation beyond the generated parameter range."),P("REST interface","H2F")]
api=[[P("Route","CellHeadF"),P("Purpose / response","CellHeadF")],
[P("GET /api/health","CellF"),P("Service status and version.","CellF")],
[P("GET /api/thermal","CellF"),P("Query: elements, length, hot, cold, generation, conductivity, area. Returns coordinates, numeric temperature, analytical reference, MAE, and residual.","CellF")],
[P("GET /api/performance","CellF"),P("Query: workers and repetitions. Returns serial/parallel time, speedup, efficiency, utilization, and numerical agreement.","CellF")],
[P("GET /api/hardware","CellF"),P("Runs MCU/FPGA/JTAG lifecycle mocks; query fault injection can simulate a timeout. Returns timestamped bus events, recovery state, and interrupt flags.","CellF")],
[P("GET /api/train","CellF"),P("Query: steps. Returns loss curve and a contextual equilibrium-temperature prediction.","CellF")]]
story += [table(api,[37*mm,139*mm]),P("Interface workflow","H2F"),P("The Geometry section accepts binary or ASCII STL and CSV coordinate/temperature data. The shader assigns temperature across mesh vertices and renders imported sample points on the same color ramp; OrbitControls provides rotation, zoom, and pan. Thermal analysis validates positive length, conductivity, and area, submits four mesh requests, displays the temperature/error table and plot, and exports a CSV. Performance times the same FEM mesh batch serially and in parallel, and plots speedup while showing utilization and result agreement. Hardware renders mock event records. Learning displays training loss and the sample regression prediction."),P("Validation performed and outstanding","H2F")]
checks=[[P("Completed here","CellHeadF"),P("JavaScript parse checks pass for app.js and three-viewer.js. Python smoke checks pass for the bundled STL/CSV, reference thermal profiles, source markers for FEM assembly, thermal batch benchmarking, device lifecycle/recovery, and gradient checking.","CellF")],[P("Not verified here","CellHeadF"),P("This authoring environment did not provide CMake or a C++ compiler. Therefore the Eigen/cpp-httplib backend has not been compiled, CTest has not been run, HTTP routes have not been exercised against a running service, and no physical device test is claimed.","CellF")],[P("Before final submission","CellHeadF"),P("On Windows with a C++17 compiler and CMake: configure/build the project, run ctest, place ForgeLabBackend.exe beside Launch.exe, test /api/health and each module in the browser, capture the actual 3-5 minute demo or timestamped screenshots, and update the AI usage log with your own review and verification.","CellF")]]
story += [table(checks,[34*mm,142*mm],header=False),Spacer(1,5),P("Build: cmake -S . -B build -A x64; cmake --build build --config Release; ctest --test-dir build -C Release --output-on-failure. First-time CMake configuration downloads pinned dependencies and needs internet access. The backend binds to 127.0.0.1:8765 only.","SmallF"),Spacer(1,5),P("AI disclosure: AI assistance helped draft code and documentation. Review the implementation, verify equations and outputs, and record your own work before submitting.","SmallF")]

# PAGE 4: concrete inputs, analytical reference values, module map, and measurable checks.
story += [PageBreak(),P("4. Data, reference cases, and verification detail","H1F"),P("Concrete thermal input set","H2F"),P("These reference cases use a 1 m uniform rod, conductivity 45 W/(m·K), cross-section 1.0×10⁻⁴ m², hot boundary 100 °C, cold boundary 20 °C, and zero volumetric heat generation. For this linear boundary-only case, every uniform mesh reproduces the exact linear nodal temperatures up to floating-point solver error. The table states the mesh configuration; it is not a recorded backend run.")]
mesh=[[P("Elements","CellHeadF"),P("Nodes","CellHeadF"),P("Spacing h (m)","CellHeadF"),P("Expected nodal max error","CellHeadF")]]
for n in (10,20,40,80): mesh.append([P(str(n),"CellF"),P(str(n+1),"CellF"),P(f"{1/n:.4f}","CellF"),P("0 analytically; numerical residual pending C++ run","CellF")])
story += [table(mesh,[27*mm,25*mm,32*mm,92*mm]),P("Nonzero heat-generation reference","H2F"),P("For k=45 W/(m·K), L=1 m, Th=100 °C, Tc=20 °C, and q=500 W/m³, the closed-form solution is T(x)=100−80x+500x(1−x)/(2·45). This independent analytical example gives the following reference values. These are calculated from the equation for report clarity, not copied from a runtime result.")]
hotmap=[[P("Position x (m)","CellHeadF"),P("Linear boundary part (°C)","CellHeadF"),P("Generation contribution (°C)","CellHeadF"),P("Analytical T (°C)","CellHeadF")]]
for x in (0,.25,.5,.75,1):
    base=100-80*x;gen=500*x*(1-x)/(2*45)
    hotmap.append([P(f"{x:.2f}","CellF"),P(f"{base:.4f}","CellF"),P(f"{gen:.4f}","CellF"),P(f"{base+gen:.4f}","CellF")])
story += [table(hotmap,[35*mm,46*mm,48*mm,47*mm]),P("Performance metrics and run protocol","H2F"),P("The benchmark forms one case each at 10, 20, 40, and 80 elements, performs one warm-up, then uses the requested repeated timings. Speedup S=T1/Tp; efficiency E=S/p (reported as a ratio); utilization is accumulated worker active time divided by elapsed time times worker count. Maximum absolute difference compares corresponding serial and parallel nodal temperatures. Timings are machine-dependent and intentionally left blank here until the C++ executable can be built and measured."),P("Module and source inventory","H2F")]
inventory=[[P("File / group","CellHeadF"),P("Responsibility","CellHeadF")],
[P("src/backend/main.cpp","CellF"),P("HTTP service startup, local binding, request parsing, validation, and REST route responses.","CellF")],
[P("src/backend/thermal.hpp","CellF"),P("FEM element assembly, boundary-condition reduction, Eigen LDLT solve, analytical profile and error metrics.","CellF")],
[P("src/backend/telemetry.*","CellF"),P("Serial/parallel thermal batch execution, repeated timing, worker utilization and agreement metrics.","CellF")],
[P("src/backend/hardware.*","CellF"),P("Mock MCU, FPGA, and JTAG device states; UART/SPI/JTAG events, timeout injection, and recovery.","CellF")],
[P("src/backend/network.*","CellF"),P("Neuron/Layer/Network model, supervised equilibrium prediction, gradient descent, finite-difference checks.","CellF")],
[P("src/frontend/*","CellF"),P("Dashboard interactions, charts, file parsing/export, Three.js STL display and temperature shader.","CellF")],
[P("tests/*","CellF"),P("C++ unit-test sources and Python smoke checks. Native test execution awaits the C++ build environment.","CellF")]]
story += [table(inventory,[47*mm,129*mm]),PageBreak(),P("5. Verification status and submission evidence","H1F"),P("The project files are prepared for a Windows x64 build, but evidence must come from the actual target machine. Use this checklist to distinguish checks already completed in the authoring environment from build and runtime checks still to capture.")]
verify=[[P("Check","CellHeadF"),P("Evidence/status","CellHeadF")],
[P("Frontend JavaScript syntax","CellF"),P("PASS: app.js and three-viewer.js parsed successfully.","CellF")],
[P("Sample-data smoke checks","CellF"),P("PASS: sample STL/CSV and source-level thermal/profile markers checked by Python smoke script.","CellF")],
[P("C++ compilation and CTest","CellF"),P("PENDING: no CMake/C++ compiler available in this authoring environment.","CellF")],
[P("HTTP API and browser integration","CellF"),P("PENDING: requires compiled backend running locally.","CellF")],
[P("Physical embedded hardware","CellF"),P("NOT CLAIMED: hardware is represented by software simulation only.","CellF")],
[P("Demonstration capture","CellF"),P("PENDING: record 3–5 minutes or provide timestamped screenshots after local runtime verification.","CellF")]]
story += [table(verify,[48*mm,128*mm]),P("Evidence to capture after the Windows build","H2F")]
evidence=[[P("Evidence item","CellHeadF"),P("What to record","CellHeadF"),P("Suggested saved file","CellHeadF")],
[P("Build and test","CellF"),P("CMake configure/build output, compiler version, and complete CTest summary including pass/fail counts.","CellF"),P("results/build-test-log.txt","CellF")],
[P("REST integration","CellF"),P("HTTP status and representative JSON from health, thermal (including errors), performance, hardware, and training routes.","CellF"),P("results/api-evidence.json","CellF")],
[P("Application demonstration","CellF"),P("Show STL interaction and temperature coloring, exported thermal CSV/plot, live worker graph, mock device events, and falling training loss.","CellF"),P("docs/demo-video.mp4 or timestamped screenshots","CellF")],
[P("Performance measurements","CellF"),P("Record worker count, repetitions, serial/parallel milliseconds, speedup, efficiency, utilization, and max serial/parallel difference on the test PC.","CellF"),P("results/performance.csv","CellF")]]
story += [table(evidence,[39*mm,91*mm,46*mm]),Spacer(1,7),banner("SUBMISSION NOTE","The analytical temperatures in Section 4 are reproducible equation-based reference data. Replace pending statuses only after saving the corresponding Windows build or runtime evidence. The current PDF remains under the Google Form 1 MB limit."),Spacer(1,7),P("AI assistance disclosure: code and report drafting received AI assistance. The submitting student should review the derivations, inspect the implementation, run the checks above, and maintain an accurate AI usage log.","BodyF")]

def footer(c,d):
    c.saveState();c.setStrokeColor(colors.HexColor("#E2E8EF"));c.line(17*mm,10*mm,A4[0]-17*mm,10*mm);c.setFont("Arial",7);c.setFillColor(muted);c.drawString(17*mm,6.5*mm,"ForgeLab | Detailed project report");c.drawRightString(A4[0]-17*mm,6.5*mm,f"Page {d.page}");c.restoreState()
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(f"Created detailed project PDF ({OUT.stat().st_size} bytes)")
