"""Regenerate checked analytical/reference CSVs using Python's standard library."""
from csv import writer
from math import exp
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
with (OUT / "thermal_profile.csv").open("w", newline="", encoding="utf-8") as stream:
    out = writer(stream); out.writerow(["elements", "x_m", "temperature_C", "analytical_C"])
    for n in (10, 20, 40, 80):
        for i in range(n + 1):
            x = i / n; temp = 100 - 80 * x
            out.writerow([n, f"{x:.8f}", f"{temp:.8f}", f"{temp:.8f}"])
with (OUT / "mesh_errors.csv").open("w", newline="", encoding="utf-8") as stream:
    out = writer(stream); out.writerow(["elements", "maximum_temperature_C", "mean_absolute_error_C", "reference_status"])
    for n in (10, 20, 40, 80): out.writerow([n, "100.00000000", "0.00000000", "linear analytical solution; zero source"])

network = {"w1": [[.15, -.2], [.25, .1]], "b1": [.05, -.05], "w2": [.3, -.25], "b2": .1}
samples = ((0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0))
sigmoid = lambda z: 1 / (1 + exp(-z))
def predict(a, b):
    h = [sigmoid(network["w1"][i][0] * a + network["w1"][i][1] * b + network["b1"][i]) for i in range(2)]
    return sigmoid(network["w2"][0] * h[0] + network["w2"][1] * h[1] + network["b2"])
def loss(): return sum(.5 * (t - predict(a, b)) ** 2 for a, b, t in samples) / 4
with (OUT / "loss.csv").open("w", newline="", encoding="utf-8") as stream:
    out = writer(stream); out.writerow(["step", "loss"]); out.writerow([0, f"{loss():.10f}"])
    for step in range(1, 101):
        for a, b, target in samples:
            z = [network["w1"][i][0] * a + network["w1"][i][1] * b + network["b1"][i] for i in range(2)]
            h = [sigmoid(v) for v in z]; output = sigmoid(network["w2"][0] * h[0] + network["w2"][1] * h[1] + network["b2"])
            d_out = (output - target) * output * (1 - output)
            for i in range(2):
                d_hidden = d_out * network["w2"][i] * h[i] * (1 - h[i])
                network["w1"][i][0] -= .5 * d_hidden * a; network["w1"][i][1] -= .5 * d_hidden * b
                network["b1"][i] -= .5 * d_hidden; network["w2"][i] -= .5 * d_out * h[i]
            network["b2"] -= .5 * d_out
        out.writerow([step, f"{loss():.10f}"])
with (OUT / "predictions.csv").open("w", newline="", encoding="utf-8") as stream:
    out = writer(stream); out.writerow(["input_a", "input_b", "target", "output", "absolute_error"])
    for a, b, target in samples:
        value = predict(a, b); out.writerow([a, b, target, f"{value:.8f}", f"{abs(value-target):.8f}"])
print("Generated thermal_profile.csv, mesh_errors.csv, loss.csv, predictions.csv")
