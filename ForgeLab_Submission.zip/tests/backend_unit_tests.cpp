#include "thermal.hpp"
#include "telemetry.hpp"
#include "hardware.hpp"
#include "network.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
int main(){using namespace forge;
    ThermalInput p;p.elements=40;auto r=solveThermal(p);assert(r.x.size()==41);assert(std::abs(r.temperature.front()-100)<1e-10);assert(std::abs(r.temperature.back()-20)<1e-10);assert(r.meanAbsoluteError<1e-9);assert(r.residualInfinity<1e-9);
    p.generation=0.01;auto generated=solveThermal(p);assert(generated.temperature[20]>60.0);assert(generated.residualInfinity<1e-8);
    ThermalInput coarse=p,fine=p;coarse.elements=10;fine.elements=80;assert(solveThermal(fine).maximumAbsoluteError<solveThermal(coarse).maximumAbsoluteError);
    Telemetry telemetry;std::vector<ThermalInput> batch{coarse,fine};auto rows=telemetry.thermalBatch(batch,3,2);assert(rows.size()==3);for(const auto&row:rows){assert(row.serialMs>0&&row.parallelMs>0);assert(row.maxDifference<1e-10);assert(row.utilization>=0&&row.utilization<=1);}
    HardwareSimulator hardware;for(const std::string device:{"Microcontroller","FPGA","JTAG adapter"}){auto events=hardware.run(device);bool failed=false,recovered=false;for(const auto&e:events){if(e.bus==device&&e.message.find("Injected timeout")!=std::string::npos)failed=true;if(e.bus==device&&e.message.find("retry successful")!=std::string::npos)recovered=true;}assert(failed&&recovered);}
    Network network;auto sample=TrainingPoint{45,1,100,20,0,60};auto checks=network.checkAllGradients(sample);assert(checks.size()==57);for(const auto&check:checks)assert(check.relativeError<1e-5);auto curve=network.train(100);assert(curve.size()==101);for(double v:curve)assert(std::isfinite(v));assert(curve.back()<curve.front());auto estimate=network.predict(sample);assert(std::isfinite(estimate));std::cout<<"All ForgeLab backend tests passed\n";
}
