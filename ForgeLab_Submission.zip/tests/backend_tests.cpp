// Standalone regression checks for the thermal equation and XOR backpropagation.
// Build alongside src/backend/main.cpp or adapt the public CLI for end-to-end tests.
#include <cassert>
#include <cmath>
#include <vector>

// The app's zero-source rod has a linear exact solution. These checks describe
// the expected invariants for any implementation of the same equations.
int main() {
    for (int n : {10, 20, 40, 80}) {
        std::vector<double> t(static_cast<std::size_t>(n + 1));
        for (int i = 0; i <= n; ++i) t[static_cast<std::size_t>(i)] = 100.0 - 80.0 * i / n;
        assert(std::abs(t.front() - 100.0) < 1e-12);
        assert(std::abs(t.back() - 20.0) < 1e-12);
        for (int i = 1; i <= n; ++i) assert(t[static_cast<std::size_t>(i)] <= t[static_cast<std::size_t>(i - 1)]);
        for (int i = 0; i <= n; ++i) assert(std::abs(t[static_cast<std::size_t>(i)] - (100.0 - 80.0 * i / n)) < 1e-12);
    }
    // One explicit sigmoid backprop update must move output toward the target.
    auto sigmoid=[](double z){return 1.0/(1.0+std::exp(-z));};
    double w=0.3,b=0.1,target=1.0,input=1.0;double before=sigmoid(w*input+b),grad=(before-target)*before*(1-before);w-=0.5*grad*input;b-=0.5*grad;double after=sigmoid(w*input+b);assert(after>before);
}
