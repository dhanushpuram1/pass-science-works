"""Offline structural and numerical smoke checks for the delivered sample files."""
from csv import DictReader
from pathlib import Path
import math
import re

ROOT = Path(__file__).resolve().parents[1]
stl = (ROOT / "data/sample_rod.stl").read_text(encoding="utf-8")
assert stl.startswith("solid sample_rod") and stl.strip().endswith("endsolid sample_rod")
assert len(re.findall(r"^\s*facet normal", stl, re.M)) == 12
with (ROOT / "data/temperature_points.csv").open(newline="", encoding="utf-8") as stream:
    points = list(DictReader(stream))
assert len(points) == 11 and float(points[0]["temperature_C"]) == 100 and float(points[-1]["temperature_C"]) == 20
assert all(math.isfinite(float(row["x_mm"])) for row in points)
with (ROOT / "results/thermal_profile.csv").open(newline="", encoding="utf-8") as stream:
    profile = list(DictReader(stream))
assert len(profile) == sum(n + 1 for n in (10, 20, 40, 80))
for row in profile:
    assert abs(float(row["temperature_C"]) - float(row["analytical_C"])) < 1e-7
with (ROOT / "results/loss.csv").open(newline="", encoding="utf-8") as stream:
    losses = list(DictReader(stream))
assert len(losses) == 101 and float(losses[-1]["loss"]) < float(losses[0]["loss"])
source = "\n".join(p.read_text(encoding="utf-8") for p in (ROOT / "src/backend").glob("*.*"))
for required in ("std::thread", "Eigen::MatrixXd", "p.generation*p.area*dx*.5", "thermalBatch", "checkAllGradients", "Injected timeout", "JTAG", "/api/thermal", "/api/performance"):
    assert required in source, f"Missing expected backend implementation: {required}"
assert (ROOT / "CMakeLists.txt").is_file() and (ROOT / "index.html").is_file()
print("PASS: input fixtures, stored references, FEM assembly, thermal benchmark, device lifecycle, gradient-check and API source markers")
